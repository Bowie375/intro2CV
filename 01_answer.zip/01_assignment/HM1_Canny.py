import numpy as np
from HM1_Convolve import Gaussian_filter, Sobel_filter_x, Sobel_filter_y
from utils import read_img, write_img

def compute_gradient_magnitude_direction(x_grad, y_grad):
    """
        The function you need to implement for Q2 a).
        Inputs:
            x_grad: array(float) 
            y_grad: array(float)
        Outputs:
            magnitude_grad: array(float)
            direction_grad: array(float) you may keep the angle of the gradient at each pixel
    """

    magnitude_grad = np.sqrt(x_grad**2 + y_grad**2)
    direction_grad = np.arctan2(y_grad, x_grad)

    return magnitude_grad, direction_grad 



def non_maximal_suppressor(grad_mag, grad_dir):
    """
        The function you need to implement for Q2 b).
        Inputs:
            grad_mag: array(float) 
            grad_dir: array(float)
        Outputs:
            output: array(float)
    """


    NMS_output = grad_mag.copy()

    # pad the gradient magnitude with zeros to avoid index out of bounds
    grad_pad = np.zeros((grad_mag.shape[0]+2, grad_mag.shape[1]+2), dtype=grad_mag.dtype)
    grad_pad[1:-1,1:-1] = grad_mag

    # [-pi/8, pi/8] and [-pi, -pi*7/8] and [pi*7/8, pi]
    x, y = np.where(np.bitwise_or(np.abs(grad_dir) < np.pi/8, np.abs(grad_dir) > np.pi*7/8))
    mask = np.bitwise_and(grad_pad[x+1, y] <= grad_pad[x+1, y+1],
                          grad_pad[x+1, y+2] <= grad_pad[x+1, y+1])
    NMS_output[x, y] = grad_mag[x, y] * mask

    # [pi*/8, pi*3/8] and [-pi*7/8, -pi*5/8]
    x, y = np.where(np.bitwise_or(
           np.bitwise_and(grad_dir >= np.pi/8, grad_dir <= np.pi*3/8),
           np.bitwise_and(grad_dir >= -np.pi*7/8, grad_dir <= -np.pi*5/8)))
    mask = np.bitwise_and(grad_pad[x, y] <= grad_pad[x+1, y+1],
                          grad_pad[x+2, y+2] <= grad_pad[x+1, y+1])
    NMS_output[x, y] = grad_mag[x, y] * mask

    # [pi*3/8, pi*5/8] and [-pi*5/8, -pi*3/8]
    x, y = np.where(np.bitwise_and(abs(grad_dir) > np.pi*3/8, abs(grad_dir) < np.pi*5/8))
    mask = np.bitwise_and(grad_pad[x, y+1] <= grad_pad[x+1, y+1],
                          grad_pad[x+2, y] <= grad_pad[x+1, y+1])
    NMS_output[x, y] = grad_mag[x, y] * mask

    # [pi*5/8, pi*7/8] and [-pi*3/8, -pi*1/8]
    x, y = np.where(np.bitwise_or(
           np.bitwise_and(grad_dir >= np.pi*5/8, grad_dir <= np.pi*7/8),
           np.bitwise_and(grad_dir >= -np.pi*3/8, grad_dir <= -np.pi*1/8)))
    mask = np.bitwise_and(grad_pad[x, y+2] <= grad_pad[x+1, y+1],
                          grad_pad[x+2, y] <= grad_pad[x+1, y+1])
    NMS_output[x, y] = grad_mag[x, y] * mask

    return NMS_output 

def hysteresis_thresholding(img) :
    """
        The function you need to implement for Q2 c).
        Inputs:
            img: array(float) 
        Outputs:
            output: array(float)
    """

    # you can adjust the parameters to fit your own implementation 
    low_ratio = 0.1
    high_ratio = 0.3

    # pad the image with zeros to avoid index out of bounds
    img_pad = np.zeros((img.shape[0]+2, img.shape[1]+2), dtype=img.dtype)
    img_pad[1:-1,1:-1] = img
    output_pad = np.where(img_pad >= high_ratio, 1.0, 0.0)

    # get idxs
    y, x = np.meshgrid(range(img.shape[1]), range(img.shape[0]))
    y, x = y.reshape(-1), x.reshape(-1)
    dy, dx = np.meshgrid(range(0,3), range(0,3))
    dy, dx = dy.reshape(-1), dx.reshape(-1)

    while True:
        refreshed = False
        output_new = np.zeros_like(output_pad)
        for i, j in zip(x, y):
            if img[i, j] < low_ratio or output_pad[i+1,j+1] > 0.5:
                continue
            if np.any(output_pad[i+dx,j+dy] > 0.5):
                output_new[i+1,j+1] = 1.0
                refreshed = True
        if not refreshed:
            break
        else:
            output_pad += output_new
            break
    return output_pad[1:-1,1:-1]

if __name__=="__main__":

    #Load the input images
    input_img = read_img("lenna.png")/255

    #Apply gaussian blurring
    blur_img = Gaussian_filter(input_img)

    x_grad = Sobel_filter_x(blur_img)
    y_grad = Sobel_filter_y(blur_img)

    #Compute the magnitude and the direction of gradient
    magnitude_grad, direction_grad = compute_gradient_magnitude_direction(x_grad, y_grad)

    #NMS
    NMS_output = non_maximal_suppressor(magnitude_grad, direction_grad)

    #Edge linking with hysteresis
    output_img = hysteresis_thresholding(NMS_output)
    
    write_img("result/HM1_Canny_result.png", output_img*255)