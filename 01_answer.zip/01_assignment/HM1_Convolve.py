import numpy as np
from utils import read_img, write_img

def padding(img, padding_size, type):
    """
        The function you need to implement for Q1 a).
        Inputs:
            img: array(float)
            padding_size: int
            type: str, zeroPadding/replicatePadding
        Outputs:
            padding_img: array(float)
    """

    if type=="zeroPadding":
        padding_img = np.zeros((img.shape[0]+2*padding_size, img.shape[1]+2*padding_size), dtype=img.dtype)
        padding_img[padding_size:padding_size+img.shape[0], padding_size:padding_size+img.shape[1]] = img
        return padding_img
    elif type=="replicatePadding":
        corner_idx = padding_size+np.array(img.shape)
        padding_img = np.zeros((img.shape[0]+2*padding_size, img.shape[1]+2*padding_size), dtype=img.dtype)
        padding_img[padding_size:corner_idx[0], padding_size:corner_idx[1]] = img
        padding_img[:padding_size,:] = padding_img[padding_size:padding_size+1,:]
        padding_img[corner_idx[0]:,:] = padding_img[corner_idx[0]-1:corner_idx[0],:]
        padding_img[:,:padding_size] = padding_img[:,padding_size:padding_size+1]
        padding_img[:,corner_idx[1]:] = padding_img[:,corner_idx[1]-1:corner_idx[1]]
        return padding_img

def convol_with_Toeplitz_matrix(img, kernel):
	"""
	    The function you need to implement for Q1 b).
	    Inputs:
	        img: array(float) 6*6
	        kernel: array(float) 3*3
	    Outputs:
	        output: array(float)
	"""
	padding_size = (kernel.shape[0]-1)//2
	(kh, kw), (ih, iw) = kernel.shape, img.shape
	#zero padding
	padding_img = padding(img, padding_size, "zeroPadding")
	ph, pw = padding_img.shape

	#build the Toeplitz matrix and compute convolution
	M = np.zeros((ih*iw, ph*pw) , dtype=img.dtype)
    
	r_idx = np.arange(ih*iw)
	r_idx_d = r_idx // iw
	c_idx_l = r_idx_d * pw + (r_idx-r_idx_d*iw)
	c_idx_l = c_idx_l.reshape(-1, 1).repeat(kh, axis=1) + np.arange(kh)*pw
	c_idx = (c_idx_l.reshape(-1, 1).repeat(kw, axis=1) + np.arange(kw)).reshape(-1)
	r_idx = (r_idx.repeat(kw*kh)).astype(int)

	M[r_idx, c_idx] = kernel.reshape(1,-1).repeat(ih*iw, axis=0).reshape(-1)
	output = np.dot(M, padding_img.reshape(-1, 1)).reshape(img.shape)
	return output


def convolve(img, kernel):
	"""
		The function you need to implement for Q1 c).
		Inputs:
		    img: array(float)
		    kernel: array(float)
		Outputs:
			output: array(float)
	"""

	#build the sliding-window convolution here
	(ih, iw), (kh, kw) = img.shape, kernel.shape
	num_elems = (ih-kh+1) * (iw-kw+1)
	c_idx, r_idx = np.meshgrid(np.arange(kw), np.arange(kh))
	r_idx, c_idx = r_idx.reshape(1, -1).repeat(num_elems, axis=0), c_idx.reshape(1, -1).repeat(num_elems, axis=0)
	r_delta = np.arange(num_elems) // (iw-kw+1)
	c_delta = np.arange(num_elems) - r_delta * (iw-kw+1)
	r_idx = (r_idx + r_delta.reshape(-1, 1)).reshape(-1)
	c_idx = (c_idx + c_delta.reshape(-1, 1)).reshape(-1)
	M = img[r_idx, c_idx].reshape(num_elems, -1)
	output = (np.dot(M, kernel.reshape(-1,1))).reshape(ih-kh+1, iw-kw+1)

	return output


def Gaussian_filter(img):
    padding_img = padding(img, 1, "replicatePadding")
    gaussian_kernel = np.array([[1/16,1/8,1/16],[1/8,1/4,1/8],[1/16,1/8,1/16]])
    output = convolve(padding_img, gaussian_kernel)
    return output

def Sobel_filter_x(img):
    padding_img = padding(img, 1, "replicatePadding")
    sobel_kernel_x = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
    output = convolve(padding_img, sobel_kernel_x)
    return output

def Sobel_filter_y(img):
    padding_img = padding(img, 1, "replicatePadding")
    sobel_kernel_y = np.array([[-1,-2,-1],[0,0,0],[1,2,1]])
    output = convolve(padding_img, sobel_kernel_y)
    return output



if __name__=="__main__":

    np.random.seed(111)
    input_array=np.random.rand(6,6)
    input_kernel=np.random.rand(3,3)


    # task1: padding
    zero_pad =  padding(input_array,1,"zeroPadding")
    np.savetxt("result/HM1_Convolve_zero_pad.txt",zero_pad)

    replicate_pad = padding(input_array,1,"replicatePadding")
    np.savetxt("result/HM1_Convolve_replicate_pad.txt",replicate_pad)


    #task 2: convolution with Toeplitz matrix
    result_1 = convol_with_Toeplitz_matrix(input_array, input_kernel)
    np.savetxt("result/HM1_Convolve_result_1.txt", result_1)

    #task 3: convolution with sliding-window
    result_2 = convolve(input_array, input_kernel)
    np.savetxt("result/HM1_Convolve_result_2.txt", result_2)

    #task 4/5: Gaussian filter and Sobel filter
    input_img = read_img("lenna.png")/255

    img_gadient_x = Sobel_filter_x(input_img)
    img_gadient_y = Sobel_filter_y(input_img)
    img_blur = Gaussian_filter(input_img)

    write_img("result/HM1_Convolve_img_gadient_x.png", img_gadient_x*255)
    write_img("result/HM1_Convolve_img_gadient_y.png", img_gadient_y*255)
    write_img("result/HM1_Convolve_img_blur.png", img_blur*255)




    