import numpy as np
from utils import  read_img, draw_corner, write_img
from HM1_Convolve import convolve, Sobel_filter_x,Sobel_filter_y,padding



def corner_response_function(input_img, window_size, alpha, threshold):
    """
        The function you need to implement for Q3.
        Inputs:
            input_img: array(float)
            window_size: int
            alpha: float
            threshold: float
        Outputs:
            corner_list: list
    """

    # please solve the corner_response_function of each window,
    # and keep windows with theta > threshold.
    # you can use several functions from HM1_Convolve to get 
    # I_xx, I_yy, I_xy as well as the convolution result.
    # for detials of corner_response_function, please refer to the slides.

    # get padding image
    padding_img = padding(input_img, 1, "replicatePadding")

    # get the gradients
    I_x = Sobel_filter_x(padding_img)
    I_y = Sobel_filter_y(padding_img)

    # get squared gradients
    I_xx = padding(I_x**2, window_size//2, "zeroPadding")
    I_yy = padding(I_y**2, window_size//2, "zeroPadding")
    I_xy = padding(I_x*I_y, window_size//2, "zeroPadding")

    # get convolution result
    gI_xx = convolve(I_xx, np.ones((window_size,window_size)))
    gI_yy = convolve(I_yy, np.ones((window_size,window_size)))
    gI_xy = convolve(I_xy, np.ones((window_size,window_size)))

    # get determinant and trace
    det = gI_xx*gI_yy - gI_xy**2
    trace = gI_xx + gI_yy

    # get corner response function
    theta = det - alpha*trace**2

    # get corner list
    x, y = np.where(theta > threshold)
    theta_val = theta[x,y]
    corner_list = np.concatenate((x.reshape(-1,1),y.reshape(-1,1),theta_val.reshape(-1,1)), axis=1)

    return list(corner_list) # the corners in corne_list: a tuple of (index of rows, index of cols, theta)



if __name__=="__main__":

    #Load the input images
    input_img = read_img("hand_writting.png")/255.

    #you can adjust the parameters to fit your own implementation 
    window_size = 5
    alpha = 0.04
    threshold = 40

    corner_list = corner_response_function(input_img,window_size,alpha,threshold)

    # NMS
    corner_list_sorted = sorted(corner_list, key = lambda x: x[2], reverse = True)
    NML_selected = [] 
    NML_selected.append(corner_list_sorted[0][:-1])
    dis = 10
    for i in corner_list_sorted :
        for j in NML_selected :
            if(abs(i[0] - j[0]) <= dis and abs(i[1] - j[1]) <= dis) :
                break
        else :
            NML_selected.append(i[:-1])


    #save results
    draw_corner("hand_writting.png", "result/HM1_HarrisCorner.png", NML_selected)
