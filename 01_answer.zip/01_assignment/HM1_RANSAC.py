import numpy as np
from utils import draw_save_plane_with_points

if __name__ == "__main__":


    np.random.seed(0)
    # load data, total 130 points inlcuding 100 inliers and 30 outliers
    # to simplify this problem, we provide the number of inliers and outliers here

    noise_points = np.loadtxt("HM1_ransac_points.txt")


    #RANSAC
    # we recommend you to formulate the palnace function as:  A*x+B*y+C*z+D=0    

    sample_time = 10 #more than 99.9% probability at least one hypothesis does not contain any outliers 
    distance_threshold = 0.05

    # sample points group
    sample_idxs = np.random.choice(np.arange(noise_points.shape[0]), (sample_time,3), replace=False)
    samples = noise_points[sample_idxs]

    # estimate the plane with sampled points group
    normal = np.cross(samples[:,0,:] - samples[:,1,:], samples[:,-1,:] - samples[:,1,:])
    A_B_C = normal
    D = (-normal * samples[:,1,:]).sum(axis=1, keepdims=True)
    A_B_C_D = np.concatenate((A_B_C, D), axis=1)


    #evaluate inliers (with point-to-plance distance < distance_threshold)
    homo_points = np.concatenate((noise_points, np.ones((noise_points.shape[0],1))), axis=1)
    distances = np.sum(np.expand_dims(A_B_C_D, axis=1) * np.expand_dims(homo_points, axis=0), axis=2)
    distances = distances**2
    mask = np.where(distances < distance_threshold**2, 1, 0)
    best_plane = np.argmax(mask.sum(axis=1))
    inliers = homo_points[mask[best_plane] == 1]
    A_B_C_D = A_B_C_D[best_plane]

    # minimize the sum of squared perpendicular distances of all inliers with least-squared method 
    U, S, VT = np.linalg.svd(inliers)
    pf = VT[-1, :]

    # draw the estimated plane with points and save the results 
    # check the utils.py for more details
    # pf: [A,B,C,D] contains the parameters of palnace function  A*x+B*y+C*z+D=0
    print("inliers: ", inliers.shape)
    draw_save_plane_with_points(pf, noise_points, "result/HM1_RANSAC_fig.png") 
    np.savetxt("result/HM1_RANSAC_plane.txt", pf)

